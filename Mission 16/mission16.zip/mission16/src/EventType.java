public enum EventType {
    OPERATIONAL,
    BROKEN_DOWN,
    REPAIRED
}
